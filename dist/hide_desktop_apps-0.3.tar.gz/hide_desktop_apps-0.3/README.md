# HideDesktopApps
A lightweight Windows system-tray app that hides and shows desktop icons, the taskbar, and all windows — perfect for revealing your Wallpaper Engine wallpaper on demand.

[![PyPI](https://img.shields.io/pypi/v/hide-desktop-apps)](https://pypi.org/project/hide-desktop-apps/)
[![Python](https://img.shields.io/pypi/pyversions/hide-desktop-apps)](https://pypi.org/project/hide-desktop-apps/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://github.com/Londopy/HideDesktopApps/blob/main/LICENSE)

---

## Install from PyPI

```bash
pip install hide-desktop-apps
hide-desktop-apps
```

Config and the tray icon are stored in `%APPDATA%\HideDesktopApps\` and created automatically on first run.

---

## Who is this for?

- **Streamers & Presenters** — automatically hide sensitive apps (email, Slack, Discord) when you start a screen-share or go live, then restore them when you're done.
- **Wallpaper Engine / desktop art fans** — reveal your animated wallpaper on demand with a single hotkey, without closing anything.
- **Kiosk & display terminals** — cleanly tuck away standard OS chrome for a dedicated display without terminating background processes.
- **Focus / productivity tools** — build Python scripts that hide distracting apps during a focus block and restore them automatically when the block ends.
- **Desktop customisation ("riced" setups)** — programmatically control the taskbar and desktop icons to match your current layout or theme.

---

## Features
- **Three configurable hotkeys** — `Ctrl+Alt+H` toggles icons, `Ctrl+Alt+T` toggles the taskbar, `Ctrl+Alt+W` toggles all windows
- **Taskbar toggle** — hide/show the taskbar from the tray or via hotkey (supports multi-monitor)
- **Tray left-click** — left-click the tray icon to toggle icons
- **Tray right-click menu** — toggle icons, taskbar, or all windows; open settings; restart; exit
- **Auto-start** — places a launcher in your Windows Startup folder, appears as **HideDesktopApps** in Task Manager → Startup tab
- **Settings window** — change all three hotkeys, startup delay, run-at-startup toggle, and default state — all without editing files
- Tiny memory footprint — pure Python, no background scanning

---

## Requirements
- Windows 10 or 11
- Python 3.7 or newer
- Packages: `pystray`, `Pillow`, `pywin32`

---

## Installation

### Via pip (recommended)
```bash
pip install hide-desktop-apps
hide-desktop-apps
```

### From source (clone this repo)
Double-click `install_and_run.bat` — a menu will appear:
```
1  FULL INSTALL  ← does everything: installs packages, adds to startup, launches app
2  Install / update Python packages only
3  Run app now
4  Add to Windows startup
5  Remove from Windows startup
6  Check startup status
7  Open this folder in Explorer
8  Run in debug mode  (shows errors in console)
0  Exit
```
Choose **1** for a first-time install.

### Manual install
```bash
pip install pystray pillow pywin32
pythonw hide_desktop.py
```
The app writes its startup entry automatically on first launch.

---

## Controls
| Action | Effect |
|---|---|
| `Ctrl+Alt+H` | Toggle desktop icons |
| `Ctrl+Alt+T` | Toggle taskbar |
| `Ctrl+Alt+W` | Toggle all open windows |
| Left-click tray icon | Toggle desktop icons |
| Right-click tray → **Toggle Desktop Icons** | Toggle desktop icons |
| Right-click tray → **Toggle Taskbar** | Hide / restore the taskbar |
| Right-click tray → **Toggle All Windows** | Hide / restore all open app windows |
| Right-click tray → **Settings…** | Open the settings window |
| Right-click tray → **Restart** | Restart the app (picks up config changes) |
| Right-click tray → **Exit** | Restore everything and quit |

---

## Tray icon guide
| Icon | Meaning |
|---|---|
| Four coloured tiles | Everything visible |
| Four coloured tiles + orange dot | Taskbar hidden |
| Four grey tiles + red X | Desktop icons hidden |
| Single large grey tile + red X | All windows hidden |

---

## Settings window
Right-click the tray icon → **Settings…** to open a tabbed settings window:

**Hotkeys tab** — set the modifier keys and letter for all three hotkeys (icons, taskbar, windows). Conflicts are detected automatically. The app restarts to apply hotkey changes.

**Startup tab** — toggle whether the app runs at Windows startup, and configure the delay (0–120 seconds) before it launches after login.

**Defaults tab** — choose whether desktop icons start hidden when the app launches.

You can also edit `config.ini` directly:
```ini
[hotkey]
modifiers = ctrl+alt
key = h

[hotkey_taskbar]
modifiers = ctrl+alt
key = t

[hotkey_windows]
modifiers = ctrl+alt
key = w

[startup]
run_at_startup = true
delay = 30

[defaults]
icons_hidden = false
```

---

## Startup management
On first launch the app drops a small VBS launcher into your Windows Startup folder. This shows up in **Task Manager → Startup tab** as **HideDesktopApps** and can be enabled/disabled there like any other startup entry.

To remove auto-start:
- Settings window → Startup tab → uncheck "Run HideDesktopApps when Windows starts"
- Installer TUI → option **5 — Remove from Windows startup**
- **Task Manager → Startup tab** → right-click `HideDesktopApps` → Disable / Delete

---

## Recovery tips

### Taskbar is hidden and you can't find the tray icon
If you hid the taskbar and the tray icon is out of reach, the quickest way to get everything back is to open a **Run dialog** (`Win+R`) or any command prompt and paste:

```python
python -c "import win32gui, win32con; win32gui.ShowWindow(win32gui.FindWindow('Shell_TrayWnd', None), win32con.SW_SHOW)"
```

This is a totally normal thing to need — `Ctrl+Alt+T` is easy to hit by accident, and the taskbar disappearing without an obvious way back is just part of learning the app. Once you're back up, consider binding the taskbar hotkey to something you're less likely to hit unintentionally, or leaving the taskbar toggle to the tray menu only.

### All windows are hidden
Press `Ctrl+Alt+W` again to restore them, or right-click the tray icon → **Toggle All Windows**.

### App isn't appearing in the tray
Run option **8 — Debug mode** in `install_and_run.bat`. This runs the app in a visible console window so any errors are shown instead of swallowed silently.

---

## Caveats & known issues

### Ghost windows after a crash
If the app is killed unexpectedly (unhandled exception, `Ctrl+C`, etc.), it registers an `atexit` handler that restores all hidden state before the process exits. However, `atexit` **does not fire** if the process is hard-killed — for example via Task Manager → End Process, or a system power loss. In that case, hidden windows remain invisible until you restore them manually (see Recovery tips above) or reboot.

For a clean shutdown always use **Right-click tray → Exit**, which explicitly restores everything before quitting.

### Antivirus false positives
This app uses Windows APIs (`RegisterHotKey`, `EnumWindows`, `ShowWindow`) that overlap with the behaviour of certain malware. Running it as a Python script is generally fine, but if you package it into a standalone `.exe` with PyInstaller, Windows Defender or other AV tools may flag it as suspicious.

**This is a false positive.** The source code is fully open and auditable in this repo. If your AV flags it, you can submit a false-positive report to your vendor or add a folder exclusion. Signing the executable with a code-signing certificate also eliminates most AV warnings, but is out of scope for a personal tool.

---

## File layout
```
HideDesktopApps/
├── hide_desktop.py      — main app
├── install_and_run.bat  — setup TUI
├── config.ini           — configuration (auto-created on first run)
├── requirements.txt     — pip dependencies
├── CHANGELOG.md         — version history
└── README.md            — this file
```
